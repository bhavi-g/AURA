
import json, argparse, sys
ap = argparse.ArgumentParser()
ap.add_argument("--results", required=True)
ap.add_argument("--f1", type=float, default=0.75)
ap.add_argument("--ece", type=float, default=0.05)
args = ap.parse_args()
res = json.load(open(args.results))
ok = (res["f1_macro"] >= args.f1) and (res["ece"] <= args.ece)
print("Results:", res)
if not ok:
    print("CI gate failed")
    sys.exit(1)
print("CI gate passed")
