# AURA – Production Starter Kit (v1)

This bundle hardens your current design into a **production-ready baseline** with:
- Frozen API/JSON schemas
- Evaluation harness and CI gate
- Security sandbox notes
- Reproducible configs (Docker + Makefile)
- Dataset manifest + model card templates

**Author:** Bhavish Goyal • Generated: 2025-10-13T11:43:58.874174Z

## Quick start
```bash
make setup
make test
make eval          # runs evaluation harness on golden set
make api           # serve FastAPI locally on :8000
```

## Repo layout
```
api/            # OpenAPI spec + FastAPI skeleton
schemas/        # JSON schemas for findings, metrics, artifacts
evaluation/     # metrics + regression harness
ci/             # GitHub Actions workflow
docker/         # Dockerfiles (worker + api) + notes
security/       # Sandbox guidance & policies
configs/        # YAML config (thresholds, models, chains)
adapters/       # Adapters for Slither/Mythril/Echidna (stubs)
model/          # UQ + calibration stubs
scripts/        # utility scripts (fingerprint, dataset manifest)
data/sample/    # tiny golden dataset example
docs/           # model card + design notes
examples/       # example reports, PoC artifact placeholders
```

## Next steps
1. Replace sample data with your **golden dataset v0.1** and expand.
2. Fill adapters with real tool calls.
3. Hook up your trained models and calibrators; update `configs/model.yaml`.
4. Enforce CI gate before merges.
