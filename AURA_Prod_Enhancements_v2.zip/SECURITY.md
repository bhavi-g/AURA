
# Security Policy
- Report vulnerabilities privately to the maintainers.
- Critical issues: 24–72h triage SLA.
- Do not upload private code without authorization.
- Analyzer jobs run in sandbox as per `security/SANDBOX.md`.
