
# Changelog
All notable changes to this project will be documented here.
- v0.1: Initial starter kit
- v2: Quality, tests, CI, compose, logging, docs, pre-commit
